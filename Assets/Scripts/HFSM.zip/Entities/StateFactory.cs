using System;
using System.Collections.Generic;

namespace Entities
{
    public abstract class StateFactory<TStateEnum> where TStateEnum : Enum
    {
        private readonly Dictionary<TStateEnum, State<TStateEnum>> _states = new();

        public abstract void RegisterStates();
    
        public State<TStateEnum> GetState(TStateEnum state)
        {
            return _states[state];
        }
        
        protected void Register(TStateEnum state, State<TStateEnum> instance)
        {
            _states.Add(state, instance);
        }
    }
}