using System;
using System.Collections.Generic;
using UnityEngine;

namespace Entities
{
    public abstract class State<TStateEnum> where TStateEnum : Enum
    {
        public TStateEnum Key { get; }
        private StateMachine<TStateEnum> StateMachine { get; }
        
        public Dictionary<TStateEnum, Func<bool>> Transitions { get; } = new();
        
        public State<TStateEnum> ParentState { get; private set; }
        public State<TStateEnum> SubState { get; private set; }
        
        protected State(TStateEnum key, StateMachine<TStateEnum> stateMachine)
        {
            Key = key;
            StateMachine = stateMachine;

            Initialize();
        }
        
        public void SetSubState(TStateEnum key)
        {
            SubState?.Exit();
            SubState = StateMachine.StateFactory.GetState(key);
            SubState.ParentState = this;
            SubState.Enter();
        }
        
        public void Enter()
        {
            OnEnter();
            SubState?.Enter();
        }

        public void Exit()
        {
            SubState?.Exit();
            OnExit();  
        }

        public void Update()
        {
            OnUpdate();
            SubState?.Update();
        }
        
        protected virtual void OnEnter() { }
        protected virtual void OnExit() { }
        protected virtual void OnUpdate() { }

        protected abstract void RegisterTransitions();

        protected void Register(TStateEnum state, Func<bool> condition)
        {
            Transitions.Add(state, condition);
        }

        protected void SetInitialSubState(TStateEnum key)
        {
            if (SubState == null)
            {
                SetSubState(key);
            }
        }
        
        private void Initialize()
        {
            RegisterTransitions();
        }

        
    }
}