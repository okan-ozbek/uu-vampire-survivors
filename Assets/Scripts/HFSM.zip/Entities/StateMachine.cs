using System;
using System.Collections.Generic;
using UnityEngine;

namespace Entities
{
    public abstract class StateMachine<TStateEnum> : MonoBehaviour where TStateEnum : Enum 
    {
        public State<TStateEnum> State { get; set; }
        public StateFactory<TStateEnum> StateFactory { get; private set; }
        
        private bool _inTransition;
        
        protected virtual void Update()
        {
            State.Update();
            
            HandleTransition();
            HandleTransition(true);
        }

        protected void InitializeStateMachine(StateFactory<TStateEnum> stateFactory, TStateEnum defaultState)
        {
            StateFactory = stateFactory;
            StateFactory.RegisterStates();

            State = StateFactory.GetState(defaultState);
            State.Enter();
        }
        
        private void HandleTransition(bool checkSubStates = false)
        {
            Dictionary<TStateEnum, Func<bool>> transitions = (checkSubStates) 
                ? State.SubState?.Transitions ?? State.Transitions
                : State.Transitions;
            
            TStateEnum nextStateKey = GetNextState(transitions, State.Key);
            if (nextStateKey.Equals(State.Key) == false)
            {
                if (checkSubStates)
                {
                    State.SetSubState(nextStateKey);
                    return;
                }
                
                State.Exit();
                State = StateFactory.GetState(nextStateKey);
                State.Enter();
            }
        }

        private TStateEnum GetNextState(Dictionary<TStateEnum, Func<bool>> transitions, TStateEnum currentState)
        {
            foreach ((TStateEnum state, Func<bool> condition) in transitions)
            {
                if (condition())
                {
                    return state;
                }
            }

            return currentState;
        }

        protected List<TStateEnum> GetActiveStateBranch(List<TStateEnum> activeStates, State<TStateEnum> currentState)
        {
            if (activeStates == null)
            {
                activeStates = new List<TStateEnum>();
            }
            
            activeStates.Add(currentState.Key);
            if (currentState.SubState != null)
            {
                GetActiveStateBranch(activeStates, currentState.SubState);
            }
         
            return activeStates;
        }
    }
}