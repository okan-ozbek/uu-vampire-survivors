﻿using Controllers.Player;
using UnityEngine;

namespace Entities.Player.States.HurtBehaviour
{
    public class PlayerHurtBehaviour : PlayerState
    {
        public PlayerHurtBehaviour(PlayerStateMachine stateMachine) : base(PlayerStateType.HurtBehaviour, stateMachine)
        {
        }
        
        protected override void OnEnter()
        {
            SetSubState(PlayerStateType.Hurt);
        }

        protected override void RegisterTransitions()
        {
            Register(PlayerStateType.MovementBehaviour, () => PlayerInputController.MovementDirection != Vector3.zero);
            Register(PlayerStateType.AttackBehaviour, () => PlayerInputController.AttackKeyPressed);
        }
    }
}