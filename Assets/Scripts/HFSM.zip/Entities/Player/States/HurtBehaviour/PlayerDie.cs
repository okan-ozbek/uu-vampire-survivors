﻿namespace Entities.Player.States.HurtBehaviour
{
    public class PlayerDie : PlayerState
    {
        public PlayerDie(PlayerStateMachine stateMachine) : base(PlayerStateType.Die, stateMachine)
        {
        }

        protected override void RegisterTransitions()
        {
            throw new System.NotImplementedException();
        }
    }
}