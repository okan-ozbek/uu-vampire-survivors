﻿namespace Entities.Player.States.HurtBehaviour
{
    public class PlayerHurt : PlayerState
    {
        public PlayerHurt(PlayerStateMachine stateMachine) : base(PlayerStateType.Hurt, stateMachine)
        {
        }

        protected override void RegisterTransitions()
        {
            throw new System.NotImplementedException();
        }
    }
}