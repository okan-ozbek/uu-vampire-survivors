﻿namespace Entities.Player.States.AttackBehaviour
{
    public class PlayerSwordHeavyAttack : PlayerState
    {
        public PlayerSwordHeavyAttack(PlayerStateMachine stateMachine) : base(PlayerStateType.SwordHeavyAttack, stateMachine)
        {
        }

        protected override void RegisterTransitions()
        {
            throw new System.NotImplementedException();
        }
    }
}