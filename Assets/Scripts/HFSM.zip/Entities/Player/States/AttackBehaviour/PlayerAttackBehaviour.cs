﻿using Controllers.Player;
using UnityEngine;

namespace Entities.Player.States.AttackBehaviour
{
    public class PlayerAttackBehaviour : PlayerState
    {
        public PlayerAttackBehaviour(PlayerStateMachine stateMachine) : base(PlayerStateType.AttackBehaviour, stateMachine)
        {
        }

        protected override void RegisterTransitions()
        {
            Register(PlayerStateType.MovementBehaviour, () => PlayerInputController.MovementDirection != Vector3.zero);
            Register(PlayerStateType.HurtBehaviour, () => PlayerInputController.DEBUG_HurtKeyPressed);
        }
    }
}