﻿namespace Entities.Player.States.AttackBehaviour
{
    public class PlayerSwordBasicAttack : PlayerState
    {
        public PlayerSwordBasicAttack(PlayerStateMachine stateMachine) : base(PlayerStateType.SwordBasicAttack, stateMachine)
        {
        }

        protected override void RegisterTransitions()
        {
            throw new System.NotImplementedException();
        }
    }
}