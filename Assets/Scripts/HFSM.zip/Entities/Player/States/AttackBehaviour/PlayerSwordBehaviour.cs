﻿namespace Entities.Player.States.AttackBehaviour
{
    public class PlayerSwordBehaviour : PlayerState
    {
        public PlayerSwordBehaviour(PlayerStateMachine stateMachine) : base(PlayerStateType.SwordBehaviour, stateMachine)
        {
        }

        protected override void RegisterTransitions()
        {
            throw new System.NotImplementedException();
        }
    }
}