﻿namespace Entities.Player.States.MovementBehaviour
{
    public class PlayerDash : PlayerState
    {
        public PlayerDash(PlayerStateMachine stateMachine) : base(PlayerStateType.Dash, stateMachine)
        {
        }

        protected override void RegisterTransitions()
        {
            throw new System.NotImplementedException();
        }
    }
}