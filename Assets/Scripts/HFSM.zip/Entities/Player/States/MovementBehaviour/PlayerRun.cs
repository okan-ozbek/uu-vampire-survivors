﻿namespace Entities.Player.States.MovementBehaviour
{
    public class PlayerRun : PlayerState
    {
        public PlayerRun(PlayerStateMachine stateMachine) : base(PlayerStateType.Run, stateMachine)
        {
            
        }

        protected override void RegisterTransitions()
        {
            throw new System.NotImplementedException();
        }
    }
}