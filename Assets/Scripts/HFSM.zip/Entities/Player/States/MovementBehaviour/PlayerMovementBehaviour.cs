﻿using Controllers.Player;

namespace Entities.Player.States.MovementBehaviour
{
    public class PlayerMovementBehaviour : PlayerState
    {
        public PlayerMovementBehaviour(PlayerStateMachine stateMachine) : base(PlayerStateType.MovementBehaviour, stateMachine)
        {
        }

        protected override void OnEnter()
        {
            SetSubState(PlayerStateType.Idle);
        }

        protected override void RegisterTransitions()
        {
            Register(PlayerStateType.AttackBehaviour, () => PlayerInputController.AttackKeyPressed);
            Register(PlayerStateType.HurtBehaviour, () => PlayerInputController.DEBUG_HurtKeyPressed);
        }
    }
}