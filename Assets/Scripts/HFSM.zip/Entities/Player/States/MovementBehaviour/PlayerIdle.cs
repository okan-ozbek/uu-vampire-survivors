﻿namespace Entities.Player.States.MovementBehaviour
{
    public class PlayerIdle : PlayerState
    {
        public PlayerIdle(PlayerStateMachine stateMachine) : base(PlayerStateType.Idle, stateMachine)
        {
        }

        protected override void RegisterTransitions()
        {
            
        }
    }
}