﻿namespace Entities.Player
{
    public abstract class PlayerState : State<PlayerStateType>
    {
        protected readonly PlayerStateMachine StateMachine;
        
        protected PlayerState(PlayerStateType key, PlayerStateMachine stateMachine) : base(key, stateMachine)
        {
            StateMachine = stateMachine;
        }
    }
}