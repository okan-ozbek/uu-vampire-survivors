﻿using Entities.Player.States.MovementBehaviour;

namespace Entities.Player
{
    public class PlayerStateFactory : StateFactory<PlayerStateType>
    {
        private readonly PlayerStateMachine _stateMachine;
        
        public PlayerStateFactory(PlayerStateMachine stateMachine)
        {
            _stateMachine = stateMachine;
        }

        public override void RegisterStates()
        {
            Register(PlayerStateType.MovementBehaviour, new PlayerMovementBehaviour(_stateMachine));
            
        }
    }
}