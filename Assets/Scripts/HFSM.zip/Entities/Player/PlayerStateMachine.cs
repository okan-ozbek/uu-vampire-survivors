﻿using System;
using System.Collections.Generic;
using TMPro;
using UnityEngine;

namespace Entities.Player
{
    public enum PlayerStateType
    {
        MovementBehaviour,
        HurtBehaviour,
        AttackBehaviour,
        SwordBehaviour,
        Dash,
        Idle,
        Run,
        Hurt,
        Die,
        SwordBasicAttack,
        SwordHeavyAttack,
    }
    
    public class PlayerStateMachine : StateMachine<PlayerStateType>
    {
        public TMP_Text DebugText;
        public Rigidbody2D Body2D { get; private set; }
        public float Health { get; set; } = 100;
        
        private void Awake()
        {
            InitializeStateMachine(
                new PlayerStateFactory(this),
                PlayerStateType.Idle
            );
        }

        private void Start()
        {
            Body2D = GetComponent<Rigidbody2D>();
        }

        private void OnDrawGizmos()
        {
            #if UNITY_EDITOR
            if (Application.isPlaying && State != null)
            {
                List<PlayerStateType> states = GetActiveStateBranch(null, State);
                // states.Reverse();
                
                Vector3 position = transform.position + Vector3.down * 2;
                
                UnityEditor.Handles.Label(position, "Active states: " + string.Join(" > ", states));
            }
            #endif
        }
    }
}