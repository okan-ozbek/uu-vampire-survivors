﻿namespace StateMachines.Player
{
    public enum PlayerStateType
    {
        Idle,
        Move,
        Dash,
        Death,
        Respawn
    }
}