﻿using Controllers.Player;
using UnityEngine;

namespace StateMachines.Player
{
    public class PlayerIdleState : PlayerBaseState
    {
        public PlayerIdleState(PlayerController controller) : base(controller)
        {
        }


        protected override void TransitionConditions()
        {
            if (PlayerInputController.MovementDirection != Vector3.zero)
            {
                Controller.TransitionTo(PlayerStateType.Move);
            }
            
            if (PlayerInputController.MovementDirection != Vector3.zero && PlayerInputController.DashKeyPressed)
            {
                Controller.TransitionTo(PlayerStateType.Dash);
            }
        }
    }
}