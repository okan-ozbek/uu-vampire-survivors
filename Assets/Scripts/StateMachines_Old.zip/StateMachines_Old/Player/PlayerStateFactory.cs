﻿using System.Collections.Generic;
using Controllers.Player;

namespace StateMachines.Player
{
    public class PlayerStateFactory : StateFactory<PlayerStateType>
    {
        public PlayerStateFactory(PlayerController controller)
        {
            States = new Dictionary<PlayerStateType, BaseState>
            {
                { PlayerStateType.Idle, new PlayerIdleState(controller) },
                { PlayerStateType.Move, new PlayerMoveState(controller) },
                { PlayerStateType.Dash, new PlayerDashState(controller) },
            };
        }
    }
}