﻿using System.Collections;
using Configs;
using Controllers.Player;
using UnityEngine;

namespace StateMachines.Player
{
    public class PlayerDashState : PlayerBaseState
    {
        private bool InDash { get; set; } = true;

        public PlayerDashState(PlayerController controller) : base(controller)
        {
        }
        
        protected override void OnEnter()
        {
            InDash = true;
            
            PlayerEventConfig.OnPlayerDash?.Invoke(Controller.Data.Guid);
            Controller.StartCoroutine(DashRoutine(PlayerInputController.NormalizedMovementDirection));
        }

        protected override void TransitionConditions()
        {
            if (InDash == false)
            {
                if (PlayerInputController.MovementDirection != Vector3.zero)
                {
                    Controller.TransitionTo(PlayerStateType.Move);
                }
                
                if (PlayerInputController.MovementDirection == Vector3.zero)
                {
                    Controller.TransitionTo(PlayerStateType.Idle);
                }
            }
        }

        private IEnumerator DashRoutine(Vector3 direction)
        {
            Controller.Rigidbody.linearVelocity = direction * 20f;
            
            yield return new WaitForSeconds(0.1f);
            
            InDash = false;
        }
    }
}