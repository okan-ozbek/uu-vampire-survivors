﻿using Controllers.Player;

namespace StateMachines.Player
{
    public abstract class PlayerBaseState : BaseState
    {
        protected readonly PlayerController Controller;
        
        protected PlayerBaseState(PlayerController controller)
        {
            Controller = controller;
        }
    }
}