﻿using Controllers.Player;
using UnityEngine;

namespace StateMachines.Player
{
    public class PlayerMoveState : PlayerBaseState
    {
        private Vector3 _velocity;
        private Camera _camera;
        
        public PlayerMoveState(PlayerController controller) : base(controller)
        {
        }

        protected override void OnEnter()
        {
            _camera = Controller.GetComponent<Camera>();
        }

        protected override void OnUpdate()
        {
            Accelerate(PlayerInputController.NormalizedMovementDirection);
            Decelerate(PlayerInputController.NormalizedMovementDirection);
            
            Controller.Rigidbody.linearVelocity = _velocity;
            
            // TODO doesn't work.
            TurnToMousePosition();
        }

        protected override void TransitionConditions()
        {
            if (PlayerInputController.MovementDirection != Vector3.zero && PlayerInputController.DashKeyPressed)
            {
                Controller.TransitionTo(PlayerStateType.Dash);
            }
            
            if (PlayerInputController.MovementDirection == Vector3.zero && _velocity == Vector3.zero)
            {
                Controller.TransitionTo(PlayerStateType.Idle);    
            }
        }
        
        private void Accelerate(Vector3 direction)
        {
            if (direction.x != 0.0f)
            {
                _velocity.x += direction.x * Controller.Data.accelerationSpeed * Time.deltaTime;
                _velocity.x = Mathf.Clamp(_velocity.x, -Controller.Data.maxAccelerationSpeed, Controller.Data.maxAccelerationSpeed);
            }
            
            if (direction.y != 0.0f)
            {
                _velocity.y += direction.y * Controller.Data.accelerationSpeed * Time.deltaTime;
                _velocity.y = Mathf.Clamp(_velocity.y, -Controller.Data.maxAccelerationSpeed, Controller.Data.maxAccelerationSpeed);
            }
        }

        private void Decelerate(Vector3 direction)
        {
            if (direction.x == 0.0f)
            {
                _velocity.x = Mathf.MoveTowards(_velocity.x, 0.0f, Controller.Data.decelerationSpeed * Time.deltaTime);
            }
            
            if (direction.y == 0.0f)
            {
                _velocity.y = Mathf.MoveTowards(_velocity.y, 0.0f, Controller.Data.decelerationSpeed * Time.deltaTime);
            }
        }

        private void TurnToMousePosition()
        {
            if (_camera == false)
            {
                return;
            }
            
            Vector3 mousePosition = _camera.ScreenToWorldPoint(Input.mousePosition);
            Vector3 direction = mousePosition - Controller.transform.position;
            
            if (direction.x > 0 && Controller.transform.localScale.x < 0)
            {
                Controller.transform.localScale = new Vector3(Mathf.Abs(Controller.transform.localScale.x), Controller.transform.localScale.y, Controller.transform.localScale.z);
            }
            
            if (direction.x < 0 && Controller.transform.localScale.x > 0)
            {
                Controller.transform.localScale = new Vector3(-Mathf.Abs(Controller.transform.localScale.x), Controller.transform.localScale.y, Controller.transform.localScale.z);
            }
        }
    }
}