﻿using System;
using System.Collections.Generic;

namespace StateMachines
{
    public abstract class StateFactory<TStateEnum> where TStateEnum : Enum
    {
        protected Dictionary<TStateEnum, BaseState> States = new();

        public BaseState GetState(TStateEnum stateType)
        {
            return States[stateType];
        }
    }
}