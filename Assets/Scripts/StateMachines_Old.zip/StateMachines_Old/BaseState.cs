﻿using System;

namespace StateMachines
{
    public abstract class BaseState
    {
        public void Enter()
        {
            OnEnter();
        }
        
        public void Update()
        {
            OnUpdate();
            TransitionConditions();
        }
        
        public void Exit()
        {
            OnExit();
        }
        
        protected virtual void OnEnter() { }
        protected virtual void OnExit() { }
        protected virtual void OnUpdate() { }
        
        protected abstract void TransitionConditions();
    }
}