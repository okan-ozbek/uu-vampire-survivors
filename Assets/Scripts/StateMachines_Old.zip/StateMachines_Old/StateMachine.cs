﻿using System;
using UnityEngine;

namespace StateMachines
{
    public abstract class StateMachine<TStateEnum> : MonoBehaviour where TStateEnum : Enum
    {
        private BaseState _currentState;
        private StateFactory<TStateEnum> _stateFactory;

        protected void InitializeStateMachine(StateFactory<TStateEnum> stateFactory, TStateEnum initialState)
        {
            _stateFactory = stateFactory;
            _currentState = _stateFactory.GetState(initialState);
            _currentState.Enter();
        }
        
        protected virtual void Update()
        {
            _currentState.Update();
        }
        
        public void TransitionTo(TStateEnum stateType)
        {
            _currentState.Exit();
            _currentState = _stateFactory.GetState(stateType);
            _currentState.Enter();
        }
    }
}